package com.demo.tests.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.demo.emirates.nbd.controller.RateController;
import com.demo.emirates.nbd.model.Rate;
import com.demo.emirates.nbd.request.CreateRateRequest;
import com.demo.emirates.nbd.request.FindAllRatesByRateIdRequest;
import com.demo.emirates.nbd.service.abstractions.IRateService;
import com.demo.tests.config.TestUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(Parameterized.class)
@WebMvcTest(value = RateController.class, secure = false)
public class RateControllerTest {

	@ClassRule
	public static final SpringClassRule SPRING_CLASS_RULE = new SpringClassRule();

	@Rule
	public final SpringMethodRule springMethodRule = new SpringMethodRule();

	@MockBean
	private IRateService transactionService;

	@Autowired
	private MockMvc mockMvc;

	private CreateRateRequest ctRequest;
	private FindAllRatesByRateIdRequest fatbuRequest;

	public RateControllerTest(CreateRateRequest ctRequest, FindAllRatesByRateIdRequest fatbuRequest) {
		this.ctRequest = ctRequest;
		this.fatbuRequest = fatbuRequest;
	}

	@Parameters
	public static Collection<Object[]> data() {

		Collection<Object[]> params = new ArrayList<>();

		CreateRateRequest request = new CreateRateRequest();

		FindAllRatesByRateIdRequest fatbuRequest1 = new FindAllRatesByRateIdRequest();
		FindAllRatesByRateIdRequest fatbuRequest2 = new FindAllRatesByRateIdRequest();
		fatbuRequest2.setRateId(0L);
		FindAllRatesByRateIdRequest fatbuRequest3 = new FindAllRatesByRateIdRequest();
		fatbuRequest3.setRateId(1236543L);

		params.add(new Object[] { request, fatbuRequest1 });
		params.add(new Object[] { request, fatbuRequest2 });
		params.add(new Object[] { request, fatbuRequest3 });

		return params;
	}

	@Test
	public void createTransaction() throws Exception {
		boolean shouldThrowBadRequest = ctRequest == null || ctRequest.getRateEffectiveDate().equals("")
				|| ctRequest.getRateExpirationDate() == null || ctRequest.getAmount() == null
				|| ctRequest.getAmount().signum() == 0 || ctRequest.getAmount().signum() == -1;

		Rate mockRate = new Rate(250L, "", BigDecimal.TEN, new Date(), new Date());

		String requestAsJson = new ObjectMapper().writeValueAsString(ctRequest);
		RequestBuilder requestBuilder = TestUtils.getPostRequestBuilder("/rate/create", requestAsJson);

		ResultActions resultActions = mockMvc.perform(requestBuilder);
		if (shouldThrowBadRequest) {
			resultActions.andExpect(MockMvcResultMatchers.status().isBadRequest());
		}

	}

	@Test
	public void findAllTransactions() throws Exception {
		List<Rate> transactionList = new ArrayList<>();
		Rate mockRate = new Rate(250L, "", BigDecimal.TEN, new Date(), new Date());
		transactionList.add(mockRate);

		Mockito.when(transactionService.findAllRatesByRateId(Mockito.any())).thenReturn(transactionList);

		boolean shouldThrowBadRequest = fatbuRequest.getRateId() == null;

		String requestAsJson = new ObjectMapper().writeValueAsString(fatbuRequest);
		RequestBuilder requestBuilder = TestUtils.getPostRequestBuilder("/rate/find/all", requestAsJson);

		ResultActions resultActions = mockMvc.perform(requestBuilder);
		if (shouldThrowBadRequest) {
			resultActions.andExpect(MockMvcResultMatchers.status().isBadRequest());
		}
	}

}
