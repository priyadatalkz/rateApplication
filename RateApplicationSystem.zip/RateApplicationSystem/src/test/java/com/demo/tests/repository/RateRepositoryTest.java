package com.demo.tests.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.demo.emirates.nbd.model.Rate;
import com.demo.emirates.nbd.repository.RateRepository;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class RateRepositoryTest {

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	private RateRepository repository;

	@Test
	public void test() {
		Rate mockRate = new Rate(250L, "", BigDecimal.TEN, new Date(), new Date());
		entityManager.persist(mockRate);
		entityManager.flush();

		assertThat(repository.findAll().size()).isEqualTo(1);

		
	}

}
