package com.demo.tests.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.demo.emirates.nbd.model.Rate;
import com.demo.emirates.nbd.repository.RateRepository;
import com.demo.emirates.nbd.service.concretions.RateService;

@RunWith(SpringJUnit4ClassRunner.class)
public class RateServiceTest {
	
	@MockBean
	private RateRepository repository;
	
	private RateService service;
	
	@Before
	public void setUp() {
		service = new RateService(repository);
	}
	
	@Test
	public void createNewTransaction() {
		Rate mockedTransaction = new Rate(25681L, true, "TRY", BigDecimal.valueOf(61268));
		Mockito.when(repository.save(Mockito.any())).thenReturn(mockedTransaction);
		
		Rate newTransaction = service.createNewTransaction(mockedTransaction.getUserId(), mockedTransaction.isBought(), mockedTransaction.getCurrency(), mockedTransaction.getAmount());
		
		assertThat(mockedTransaction.getAmount()).isEqualTo(newTransaction.getAmount());
		assertThat(mockedTransaction.getCurrency()).isEqualTo(newTransaction.getCurrency());
		assertThat(mockedTransaction.getUserId()).isEqualTo(newTransaction.getUserId());
		assertThat(mockedTransaction.isBought()).isEqualTo(newTransaction.isBought());
	}
	
	@Test
	public void getOperationCountFromLast24Hours() {
		Mockito.when(repository.getOperationCountFromLast24Hours(Mockito.any())).thenReturn(20);
		
		int operationCount = service.getOperationCountFromLast24Hours(12161L);
		assertThat(operationCount).isPositive();
	}
	
	@Test
	public void findAllByUserId() {
		List<Rate> transactionList = new ArrayList<>();
		Rate mockedTransaction = new Rate(61682L, true, "EUR", BigDecimal.valueOf(12661));
		transactionList.add(mockedTransaction);
		
		Mockito.when(repository.findAllByRateId(Mockito.any())).thenReturn(transactionList);
		
		List<Rate> foundTransactionList = service.findAllByRateId(mockedTransaction.getUserId());
		assertThat(foundTransactionList).isEqualTo(transactionList);
	}

}
