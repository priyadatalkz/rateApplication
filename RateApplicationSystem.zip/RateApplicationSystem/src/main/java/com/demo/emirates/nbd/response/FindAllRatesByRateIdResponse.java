package com.demo.emirates.nbd.response;

import java.util.List;

import com.demo.emirates.nbd.model.Rate;

import lombok.Data;

@Data
public class FindAllRatesByRateIdResponse {
	private List<Rate> rateList;

	public List<Rate> getRateList() {
		return rateList;
	}

	public void setRateList(List<Rate> rateList) {
		this.rateList = rateList;
	}
	
	
}
