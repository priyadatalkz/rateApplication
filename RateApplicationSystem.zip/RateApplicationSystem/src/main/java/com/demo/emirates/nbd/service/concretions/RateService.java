package com.demo.emirates.nbd.service.concretions;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.emirates.nbd.model.Rate;
import com.demo.emirates.nbd.repository.RateRepository;
import com.demo.emirates.nbd.service.abstractions.IRateService;

@Service
public class RateService implements IRateService {

	private RateRepository repository;

	@Autowired
	public RateService(RateRepository repository) {
		this.repository = repository;
	}


	@Override
	public List<Rate> findAllRatesByRateId(Long rateId) {
		return repository.findAllByRateId(rateId);
	}

	@Override
	public Rate createNewRate(Long rateId, String rateDescription, BigDecimal amount, Date rateEffectiveDate,
			Date rateExpirationDate) {
		Rate rate = new Rate(rateId, rateDescription, amount, rateEffectiveDate, rateExpirationDate);
		return repository.save(rate);

	}


	@Override
	public void updateRate(Long rateId, String rateDescription, BigDecimal amount, Date rateEffectiveDate,
			Date rateExpirationDate) {
		 repository.updateRate(rateId, rateDescription, amount, rateEffectiveDate, rateExpirationDate);
	}
	
	@Override
	public void deleteRate(Long rateId) {
		repository.deleteRate(rateId);
	}


}
