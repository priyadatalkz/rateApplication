package com.demo.emirates.nbd.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table( name = "RATE" )
public class Rate {

	private @Id @GeneratedValue Long RateId;
	private String RateDescription;
	private BigDecimal amount;
	private Date RateEffectiveDate;
	private Date RateExpirationDate;


	public Rate(Long rateId, String rateDescription, BigDecimal amount, Date rateEffectiveDate,
			Date rateExpirationDate) {
		super();
		RateId = rateId;
		RateDescription = rateDescription;
		this.amount = amount;
		RateEffectiveDate = rateEffectiveDate;
		RateExpirationDate = rateExpirationDate;
	}

}
