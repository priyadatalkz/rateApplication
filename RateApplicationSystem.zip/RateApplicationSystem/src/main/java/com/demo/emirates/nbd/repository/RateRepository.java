package com.demo.emirates.nbd.repository;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.demo.emirates.nbd.model.Rate;

@RepositoryRestResource(exported = false)
public interface RateRepository extends JpaRepository<Rate, Long> {

	@Query(value = "SELECT RateId,RateDescription,RateEffectiveDate,RateExpirationDate,Amount FROM RATE WHERE RateId = :RateId")
	List<Rate> findAllByRateId(Long rateId);

	@Query(value = "Update RATE set RateId=:rateId,RateDescription=:rateDescription,RateEffectiveDate=:rateEffectiveDate,RateExpirationDate=:rateExpirationDate,Amount=:amount FROM RATE WHERE RateId = :RateId")
	List<Rate> updateRate(Long rateId, String rateDescription, BigDecimal amount, Date rateEffectiveDate,
			Date rateExpirationDate);

	@Query(value = "DELETE FROM RATE WHERE RateId=:RateId")
	void deleteRate(@Param("RateId") Long RateId);

}
