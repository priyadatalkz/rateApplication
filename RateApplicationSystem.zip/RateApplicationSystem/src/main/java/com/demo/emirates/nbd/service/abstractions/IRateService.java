package com.demo.emirates.nbd.service.abstractions;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.demo.emirates.nbd.model.Rate;

public interface IRateService {

	List<Rate> findAllRatesByRateId(Long rateId);

	Rate createNewRate(Long RateId, String RateDescription, BigDecimal amount, Date RateEffectiveDate,
			Date RateExpirationDate);
	
	void updateRate(Long RateId, String RateDescription, BigDecimal amount, Date RateEffectiveDate,
			Date RateExpirationDate);

	void deleteRate(Long rateId);

}
