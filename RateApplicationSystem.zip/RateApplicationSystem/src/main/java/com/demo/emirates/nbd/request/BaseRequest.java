package com.demo.emirates.nbd.request;

public class BaseRequest {

}
