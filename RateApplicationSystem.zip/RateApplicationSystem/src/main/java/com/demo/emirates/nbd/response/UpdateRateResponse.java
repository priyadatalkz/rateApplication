package com.demo.emirates.nbd.response;

import com.demo.emirates.nbd.model.Rate;

import lombok.Data;

@Data
public class UpdateRateResponse {

	private Rate rate;

	public Rate getTransaction() {
		return rate;
	}

	public void setTransaction(Rate transaction) {
		this.rate = transaction;
	}
	
	

}
