package com.demo.emirates.nbd.response;

import com.demo.emirates.nbd.model.Rate;

import lombok.Data;

@Data
public class CreateRateResponse {

	private Rate transaction;

	public Rate getTransaction() {
		return transaction;
	}

	public void setTransaction(Rate transaction) {
		this.transaction = transaction;
	}
	
	

}
