package com.demo.emirates.nbd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.emirates.nbd.configuration.Constants;
import com.demo.emirates.nbd.model.Rate;
import com.demo.emirates.nbd.request.CreateRateRequest;
import com.demo.emirates.nbd.request.DeleteRateRequest;
import com.demo.emirates.nbd.request.FindAllRatesByRateIdRequest;
import com.demo.emirates.nbd.request.UpdateRateRequest;
import com.demo.emirates.nbd.response.CreateRateResponse;
import com.demo.emirates.nbd.response.FindAllRatesByRateIdResponse;
import com.demo.emirates.nbd.response.UpdateRateResponse;
import com.demo.emirates.nbd.service.abstractions.IRateService;

@RestController
@RequestMapping(value = "/rate", produces = { MediaType.APPLICATION_JSON_VALUE })
public class RateController {

	private IRateService rateService;

	@Autowired
	public RateController(IRateService rateService) {
		this.rateService = rateService;
	}

	@PostMapping("/add")
	public CreateRateResponse createRate(@RequestBody CreateRateRequest request) throws Exception {

		try {

			Rate rate = rateService.createNewRate(request.getRateId(), request.getRateDescription(),
					request.getAmount(), request.getRateEffectiveDate(), request.getRateExpirationDate());
			CreateRateResponse response = new CreateRateResponse();
			response.setTransaction(rate);
			return response;
		} catch (Exception e) {
			throw new Exception(Constants.MESSAGE_RATE_EXCEPTION);

		}
	}

	@PostMapping("/update")
	public void updateRate(@RequestBody UpdateRateRequest request) throws Exception {

		try {

			rateService.updateRate(request.getRateId(), request.getRateDescription(), request.getAmount(),
					request.getRateEffectiveDate(), request.getRateExpirationDate());

		} catch (Exception e) {
			throw new Exception(Constants.MESSAGE_RATE_EXCEPTION);

		}
	}

	@PostMapping("/search/rate")
	public FindAllRatesByRateIdResponse findAll(@RequestBody FindAllRatesByRateIdRequest request) {

		List<Rate> rateList = rateService.findAllRatesByRateId(request.getRateId());

		FindAllRatesByRateIdResponse response = new FindAllRatesByRateIdResponse();
		response.setRateList(rateList);
		return response;
	}

	@PostMapping("deleteRate")
	public void deleteRate(@RequestBody DeleteRateRequest request) throws Exception {
		try {
			rateService.deleteRate(request.getRateId());
		} catch (Exception e) {
			throw new Exception(Constants.MESSAGE_RATE_EXCEPTION);

		}
	}

}
