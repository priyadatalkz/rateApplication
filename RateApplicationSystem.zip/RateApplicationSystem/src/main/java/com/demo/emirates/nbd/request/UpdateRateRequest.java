package com.demo.emirates.nbd.request;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class UpdateRateRequest extends BaseRequest {

	private @Id @GeneratedValue Long RateId;
	private String RateDescription;
	private BigDecimal amount;
	private Date RateEffectiveDate;
	private Date RateExpirationDate;
	public Long getRateId() {
		return RateId;
	}
	public void setRateId(Long rateId) {
		RateId = rateId;
	}
	public String getRateDescription() {
		return RateDescription;
	}
	public void setRateDescription(String rateDescription) {
		RateDescription = rateDescription;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public Date getRateEffectiveDate() {
		return RateEffectiveDate;
	}
	public void setRateEffectiveDate(Date rateEffectiveDate) {
		RateEffectiveDate = rateEffectiveDate;
	}
	public Date getRateExpirationDate() {
		return RateExpirationDate;
	}
	public void setRateExpirationDate(Date rateExpirationDate) {
		RateExpirationDate = rateExpirationDate;
	}
	
	

	
}
